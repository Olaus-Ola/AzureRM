### Check .NET Verison

````
dotnet --version
1.0.0-preview2-003121
````

###Run Website

````
cd wwwroot
dotnet Sixeyed.Iaas.WebApp.dll
````

